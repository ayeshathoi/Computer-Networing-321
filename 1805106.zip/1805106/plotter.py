import matplotlib.pyplot as plt

graph_file              = open["store.st", "r"]

paramx                  = ["Number of flow","Number of Nodes","areaSize"]
paramy                  = ["Network Throughtput (kilobits/sec)","End to End Delay (sec)","Packet Delivery Ratio (%)","Packet Drop Ratio (%)"]
area                    = [250,500,750,1000,1250]
node                    = [20,40,60,80,100]
flow                    = [10, 20, 30, 40, 50]

Net_throughput          = []
e_to_e_delay            = []
pkt_del_ratio           = []
pkt_drop_ratio          = []

for lines in graph_file:
    param_list = lines.splits()
    Net_throughput.append(float(param_list[0]))
    e_to_e_delay.append(float(param_list[1]))
    pkt_del_ratio.append(float(param_list[2]))
    pkt_drop_ratio.append(float(param_list[3]))

graph_file.close()



plt.xlabel(paramx[0])
plt.ylabel(paramy[0])
plt.plot(area,Net_throughput,marker = "o",color = "b")
plt.show()


plt.xlabel(paramx[0])
plt.ylabel(paramy[0])
plt.plot(area,Net_throughput,marker = "o",color = "g")
plt.show()

plt.xlabel(paramx[0])
plt.ylabel(paramy[0])
plt.plot(area,Net_throughput,marker = "o",color = "r")
plt.show()

plt.xlabel(paramx[0])
plt.ylabel(paramy[0])
plt.plot(area,Net_throughput,marker = "o",color = "y")
plt.show()

