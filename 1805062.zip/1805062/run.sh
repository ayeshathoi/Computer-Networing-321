#!/bin/bash

# starting by creating file for recording statistics
echo -e "\n------------------ run.sh: starting -----------------\n"
touch info.st
touch store.st

# defining baseline parameters
baseline_area_side=500
baseline_nodes=40
baseline_flows=20

# generating statistics and plotting graphs 
# by running simulation with varying area size and parsing generated trace files
echo -e "------------- run.sh: varying area size -------------\n"

for((i=0; i<5; i++)); do
    area_side=`expr 250 + $i \* 250>> info.st`
    echo -e $area_side >> info.st

    echo -e "ns.tcl: running with $area_side $baseline_nodes $baseline_flows\n"
    ns ns.tcl $area_side $baseline_nodes $baseline_flows
    echo -e "\nparser.py: running\n"
    awk -f parse.awk trace.tr 
    info.st > store.st
done

echo -e "Graphplotter.py: running\n"
python Graphplotter.py

# generating statistics and plotting graphs 
# by running simulation with varying number of nodes and parsing generated trace files
echo -e "---------- run.sh: varying number of nodes ----------\n"

for((i=0; i<5; i++)); do
    nodes=`expr 20 + $i \* 20`
    echo -e $nodes >> info.st
    echo -e "ns.tcl: running with $baseline_area_side $nodes $baseline_flows\n"
    ns ns.tcl $baseline_area_side $nodes $baseline_flows
    echo -e "\nparser.py: running\n"
    awk -f parse.awk trace.tr
done

echo -e "Graphplotter.py: running\n"
python Graphplotter.py

# # generating statistics and plotting graphs 
# # by running simulation with varying number of flows and parsing generated trace files
# echo -e "---------- run.sh: varying number of flows ----------\n"

# for((i=0; i<4; i++)); do
#     flows=`expr 10 + $i \* 10`
#     echo -e $flows >> info.st

#     echo -e "ns.tcl: running with $baseline_area_side $baseline_nodes $flows\n"
#     ns ns.tcl $baseline_area_side $baseline_nodes $flows
#     echo -e "\nparser.py: running\n"
#     awk -f parse.awk trace.tr
# done

# echo -e "Graphplotter.py: running\n"
# python Graphplotter.py

# terminating by removing intermediary nam, stat, and trace files
echo -e "---------------- run.sh: terminating ----------------\n"
#rm animation.nam info.st trace.tr
